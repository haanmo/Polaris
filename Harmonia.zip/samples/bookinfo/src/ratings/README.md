# haanmo-bookinfo-ratings
