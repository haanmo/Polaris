import java.util.ArrayList;
import java.util.List;

public class ContainerBoundary {
	int Ns; // the number of services
	int Nc; // the number of containers
	List<List<Integer>> stirlingSet = new ArrayList<>();
	List<List<List<Integer>>> designOptions = new ArrayList<>();
	
	ContainerBoundary() {
	}
	
	
	
	
}
