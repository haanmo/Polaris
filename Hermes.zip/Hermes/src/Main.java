import java.io.FileNotFoundException;
import java.io.IOException;

public class Main {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		MatrixOperator op = new MatrixOperator();

		// JIRA : https://www.guru99.com/jira-tutorial-a-complete-guide-for-beginners.html
		// JIRA is a tool developed by Australian Company Atlassian. This software is used for bug tracking, issue tracking, and project management.

		
		// [input] T_s (Nc, 1). time to change software services (use case).
		// assuming that we can get logs from (change request time) JIRA and Github (code push time)
		// (change time of each software service (use case)) =  (change request time) - (code push time)

		
		
		// [input] CS (Nc, Ns). container-service matrix.
		
		// [input] F_s (Ns, Ns). represents the degree of communications between business services. 
				//be default, assigns 0.5 to Extend relationship, and 1.0 to Include relationships in use case models
		
		

		// [input] T_sl (Ns, Ns). user input that represents the time to test communication links between business services
				// assuming that we can get logs from (time to test communication links) DevOps, testing phases.
		
		
		// [input] P_g (Ns, Ns). user input that represents business process level services experiencing slow change delivery
				// assuming that we can get logs from (change request time) JIRA and Github (code push time)
				// (slow change business task) = ( (change request time) - (code push time) ) > threshold
		
		// [input] P_g (Ns, Ns). user input that represents business process level services experiencing slow performance issues
				// assuming that we can get logs from (change request time) Business Process Execution Monitoring framework, e.g., Camunda, or BPEL frameworks
				// (slow performance task) = (average latency) > threshold
		
		// [input] S_s (Ns, 1). represents the module size for a software service (use case)
				// assuming that we can get the size from Github
		
		// [input] W_g (Ns, Ns). user input that represents weights of change dependencies between business service.
				// tendency of requesting changes together. such as Recommendation service changes -> Landing Page Service Changes
				// assuming that we can get logs from JIRA.
		
		
		////////// K1
		// [input] CS (Nc, Ns). container-service matrix.
		// [input] T_s (Nc, 1). time to change services.
		// [derived] T_c. time to change a container
		Matrix CS = new Matrix("/Users/haanmo/Documents/Programming/Java/Workspace_ModelingEclipse/Hermes/src/CS.txt");
		Matrix T_s = new Matrix("/Users/haanmo/Documents/Programming/Java/Workspace_ModelingEclipse/Hermes/src/T_s.txt");
		Matrix T_c = op.multiplication(CS, T_s);
		int N_c = T_c.rows;
		double K1 = (double) op.sum(T_c) / N_c;
		System.out.println("K1: " + K1);
		
		////////// K2
		// [input] W_g
		// [derived] D_c
		// [derived] T_d		
		Matrix W_g = new Matrix("/Users/haanmo/Documents/Programming/Java/Workspace_ModelingEclipse/Hermes/src/W_g.txt");
		Matrix D_c = op.multiplication(op.multiplication(CS, W_g), op.transpose(CS));
		Matrix T_d = op.multiplication(op.minus(D_c, op.diag(D_c)), T_c);
		double K2 = (double) op.sum(T_d) / N_c;
		System.out.println("K2: " + K2);
		
		////////// K3
		// [input] T_sl
		// [input] w_cl_out
		// [derived] T_l
		// [derived] T_cl_in
		// [derived] T_l_fo
		// [derived] T_l_fi
		// [derived] T_cl_out
		// [derived] T_cl
		Matrix T_sl = new Matrix("/Users/haanmo/Documents/Programming/Java/Workspace_ModelingEclipse/Hermes/src/T_sl.txt");
		Matrix T_l = op.multiplication(op.multiplication(CS, T_sl), op.transpose(CS));
		Matrix T_cl_in = op.multiplication(op.diag(T_l), op.getOnes(N_c));
		Matrix T_l_fo = op.minus(op.multiplication(T_l, op.getOnes(N_c)), T_cl_in);
		Matrix T_l_fi = op.minus(op.multiplication(op.transpose(T_l), op.getOnes(N_c)), T_cl_in);
		double w_cl_out = 2.0;
		Matrix T_cl_out = op.multiplication(op.plus(T_l_fo, T_l_fi), w_cl_out);
		Matrix T_cl = op.plus(T_cl_in, T_cl_out);
		double K3 = (double) op.sum(T_cl) / N_c;
		System.out.println("K3: " + K3);
		

		////////// K4
		// [derived] T_dl
		Matrix T_dl = op.multiplication(op.minus(D_c, op.diag(D_c)), T_cl);
		double K4 = (double) op.sum(T_dl) / N_c;
		System.out.println("K4: " + K4);

		////////// K5
		// [derived] T_g
		Matrix T_g = op.plus(T_c, op.plus(T_d, op.plus(T_cl, T_dl)));
		double K5 = (double) op.sum(T_g) / N_c;
		System.out.println("K5: " + K5);
		
		////////// K6
		// [input] P_g
		// [derived] CGS
		// [derived] CGSF
		// [derived] T_cg
		Matrix P_g = new Matrix("/Users/haanmo/Documents/Programming/Java/Workspace_ModelingEclipse/Hermes/src/P_g.txt");
		Matrix CGS = op.multiplication(op.multiplication(CS, P_g), op.transpose(CS));
		Matrix CGSF = op.and(CGS, CGS);
		Matrix T_cg = op.multiplication(CGSF, T_g);
		double K6 = (double) op.sum(T_cg) / N_c;
		System.out.println("K6: " + K6);
		
		////////// K7
		// [input] S_s
		// [derived] S_c
		Matrix S_s = new Matrix("/Users/haanmo/Documents/Programming/Java/Workspace_ModelingEclipse/Hermes/src/S_s.txt");
		Matrix S_c = op.multiplication(CS, S_s);
		double K7 = (double) op.sum(S_c) / N_c;
		System.out.println("K7: " + K7);
		
		////////// K8
		// [input] F_s 
		// [derived] F_c
		// [derived] F_c_out
		Matrix F_s = new Matrix("/Users/haanmo/Documents/Programming/Java/Workspace_ModelingEclipse/Hermes/src/F_s.txt");
		Matrix F_c = op.multiplication(op.multiplication(CS, F_s), op.transpose(CS));
		Matrix F_c_out = op.minus(F_c, op.diag(F_c));
		double K8 = (double) op.sum(F_c_out) / N_c;
		System.out.println("K8: " + K8);
		
		////////// K9		
		// [input] P_p
		// [derived] CPS
		// [derived] CPSF
		// [derived] S_pc
		Matrix P_p = new Matrix("/Users/haanmo/Documents/Programming/Java/Workspace_ModelingEclipse/Hermes/src/P_p.txt");
		Matrix CPS = op.multiplication(op.multiplication(CS, P_p), op.transpose(CS));
		Matrix CPSF = op.and(CPS, CPS);
		Matrix S_pc = op.multiplication(CPSF, S_c);
		double K9 = (double) op.sum(S_pc) / N_c;
		System.out.println("K9: " + K9);
		
		
		//n: 6, k: 1, 2, 3, ... 6
		// n: 6, k: 3
		// (1, 1, 4), (1, 2, 3), (1, 3, 2), (1, 4, 1)
		// (2, 1, 3), (2, 2, 2), (2, 3, 1)
		// (3, 1, 2), (3, 2, 1)
		// (4, 1, 1)
		
		// n: 6
		// 1. k -> a list of stiring numbers
		//		e.g., 3 -> (1, 1, 4), (1, 2, 3), (1, 3, 2), (1, 4, 1), (2, 1, 3), (2, 2, 2), (2, 3, 1)
		// 2. a stiring number  -> combinations
		//		e.g., (2, 1, 3) -> {(1,2), (3), (4,5,6)}, {(1,3), (2), (4,5,6)}, ..., {(2,3), (1), (4,5,6)}, ...
	}

}
