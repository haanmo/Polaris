import java.util.*;
import java.io.*;

public class Matrix {
	String filePath = null;
	int rows;
	int cols;
	double[][] matrix;
	
	Matrix(String filePath) throws FileNotFoundException, IOException {
		this.filePath = filePath;
		List<String> lines = new ArrayList<String>();
		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			String line;
		    while ((line = br.readLine()) != null) {
		    	lines.add(line);
		    }
		} 
		
		rows = lines.size();
		cols = lines.get(0).split("\t").length;		
		matrix = new double[rows][cols];
		for (int i = 0; i < rows; i++) {
			String[] cells = lines.get(i).split("\t");
			for (int j = 0; j < cols; j++) {
				matrix[i][j] = Double.valueOf(cells[j]);
				//System.out.print(matrix[i][j] + " ");
			}
			//System.out.println();
		}
	}
	
	Matrix(int rows, int cols) {
		this.rows = rows;
		this.cols = cols;
		this.matrix = new double[rows][cols];
	}
	
 

}
