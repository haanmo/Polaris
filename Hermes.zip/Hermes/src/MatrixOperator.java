
public class MatrixOperator {
	
	public Matrix multiplication (Matrix m1, Matrix m2) {
		
		if (m1.cols != m2.rows) return null;
		Matrix result = new Matrix(m1.rows, m2.cols);
		
		for (int i = 0; i < m1.rows; i++) {
			for (int j = 0; j < m2.cols; j++) {
				result.matrix[i][j] = 0;
				for (int k = 0; k < m2.rows; k++) {
					result.matrix[i][j] += m1.matrix[i][k] * m2.matrix[k][j];
				}
			}
		}
		return result;
	}
	
	public Matrix multiplication (Matrix m1, double w) {
		
		Matrix result = new Matrix(m1.rows, m1.cols);
		for (int i = 0; i < m1.rows; i++) {
			for (int j = 0; j < m1.cols; j++) {
				result.matrix[i][j] = w * m1.matrix[i][j];
			}
		}
		return result;
	}
	
	public Matrix transpose (Matrix m) {
		Matrix transposed = new Matrix(m.cols, m.rows);
		for (int i = 0; i < m.rows; i++) {
			for (int j = 0; j < m.cols; j++) {
				transposed.matrix[j][i] = m.matrix[i][j];
			}
		}
		return transposed;
	}
	
	public Matrix diag(Matrix m) {
		Matrix identity = new Matrix(m.rows, m.cols);
		for (int i = 0; i < m.rows; i++) {
			for (int j = 0; j < m.cols; j++) {
				if (i == j) identity.matrix[i][j] = m.matrix[i][j];
			}
		}
		return identity;
	}
	
	public Matrix minus(Matrix m1, Matrix m2) {
		if (m1.rows != m2.rows || m1.cols != m2.cols) return null;
		
		Matrix result = new Matrix(m1.rows, m1.cols); 
		for (int i = 0; i < m1.rows; i++) {
			for (int j = 0; j < m1.cols; j++) {
				result.matrix[i][j] = m1.matrix[i][j] - m2.matrix[i][j];
			}
		}
		return result;
	}
	
	public Matrix plus(Matrix m1, Matrix m2) {
		if (m1.rows != m2.rows || m1.cols != m2.cols) return null;
		
		Matrix result = new Matrix(m1.rows, m1.cols); 
		for (int i = 0; i < m1.rows; i++) {
			for (int j = 0; j < m1.cols; j++) {
				result.matrix[i][j] = m1.matrix[i][j] + m2.matrix[i][j];
			}
		}
		return result;
	}
	
	public Matrix and(Matrix m1, Matrix m2) {
		if (m1.rows != m2.rows || m1.cols != m2.cols) return null;
		
		Matrix result = new Matrix(m1.rows, m1.cols); 
		for (int i = 0; i < m1.rows; i++) {
			for (int j = 0; j < m1.cols; j++) {
				result.matrix[i][j] = m1.matrix[i][j] > 0 && m2.matrix[i][j] > 0 ? 1 : 0;
			}
		}
		return result;
	}
	
	
	public double sum(Matrix m) {
		
		double result = 0;
		for (int i = 0; i < m.rows; i++) {
			for (int j = 0; j < m.cols; j++) {
				result += m.matrix[i][j];
			}
		}
		return result;
	}
	
	public Matrix getOnes(int rows) {
		Matrix ones = new Matrix(rows, 1);
		for (int i = 0; i < rows; i++) {
			ones.matrix[i][0] = 1.0;
		}
		return ones;
	}
	
	public void printMatric(Matrix m) {
		for (int i = 0; i < m.rows; i ++) {
			for (int j = 0; j < m.cols; j++) {
				System.out.print(m.matrix[i][j] + " ");
			}
			System.out.println();
		}
	}
}
