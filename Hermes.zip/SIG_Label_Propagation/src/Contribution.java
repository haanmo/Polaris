/*

Developer: 
	Haan Mo Johng

Date:
	04.04.2018.

Description:

Note:
	 

 */
public enum Contribution {
	Make,
	Help,
	Hurt,
	Break;
}
