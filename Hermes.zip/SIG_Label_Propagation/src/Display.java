import java.util.List;

public class Display {
	
	Display(){}
	
	public void printGoals (List<Goal> goals) {
		
		for (Goal goal : goals) {
			System.out.println(goal.topic + " " + goal.type + " " + goal.labeled);
			for (Goal subGoal : goal.getChildGoals()) {
				System.out.println("\t subgoal: "+subGoal.type + " " +subGoal.topic);
			}
		}
	}
}
