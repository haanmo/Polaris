import java.util.ArrayList;
import java.util.List;

/*

Developer: 
	Haan Mo Johng

Date:
	04.04.2018.

Description:

Note:
	Link and child goals should have same index. 

 */

public class Goal {
	// a enum list of labels
	Label label = null; 
	Boolean labeled;
	
	// name of this goal
	String type = null;
	String topic = null;
	
	// a list of parent and child goals
	private List<Goal> parentGoals = null;
	private List<Goal> childGoals = null;
	private List<Link> links = null;	// link between this node and children
	
	Goal() {
		this("Type", "Topic");
	}
	
	Goal(String type, String topic) {
		this.type = type;
		this.topic = topic;
		labeled = false;
		parentGoals = new ArrayList<Goal>();
		childGoals = new ArrayList<Goal>();
		links = new ArrayList<Link>();
	}
	
	// temparal add function.
	public void addChild (Goal child) {
		childGoals.add(child);
	}
	
	public void addParent (Goal parent) {
		parentGoals.add(parent);
	}
	
	public List<Goal> getChildGoals(){
		return childGoals;
	}
	
	public List<Goal> getParentGoals(){
		return parentGoals;
	}
	
	public void setLinks(Link link){
		this.links.add(link);
	}
	
	int calcContributions () {
		return 0;
	}
	
	public int calcLabel () {
		return 0;
	}
	
}
