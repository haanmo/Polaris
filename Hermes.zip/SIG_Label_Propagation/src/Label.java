
/*

Developer: 
	Haan Mo Johng

Date:
	04.04.2018.

Description:

Note:
	 

 */

public enum Label {
	Satisficed,
	Weakly_Satisficed,
	Weakly_Denied,
	Denied;
}
