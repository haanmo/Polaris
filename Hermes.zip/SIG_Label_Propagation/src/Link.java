import java.util.List;

/*

Developer: 
	Haan Mo Johng

Date:
	04.04.2018.

Description:

Note:
	 

 */

public class Link {
	// a enum list of labels
	Label label = null; 
	Contribution contribution = null;
				
	// a list of parent and child goals
	Goal parent = null;
	Goal child = null;
	
	// default constructor
	Link () {
		
	}
	
	// constructor
	Link (Goal child, Goal parent, Contribution contribution, Label label) {
		this.child = child;
		this.parent = parent;
		this.label = label;
		this.contribution = contribution;
		
		this.child.addParent(this.parent);
		this.parent.addChild(this.child);
		this.parent.setLinks(this);
	}
	
	public void updateChildAndParent () {
		// link is only for a goal and subgoals (between a parent and children)
		// do not include this instruction in a constructor. It causes problems when using multi-threads.
		this.parent.setLinks(this);
	}
}
