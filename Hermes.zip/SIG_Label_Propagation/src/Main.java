import java.util.ArrayList;
import java.util.List;

/*

Developer: 
	Haan Mo Johng

Date:
	04.04.2018.

Description:

Note:
	 

 */

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int goal_size = 10;
		
		List<Goal> goals = new ArrayList<Goal>();
		List<Link> links = new ArrayList<Link>();
		Propagator propagator = null;
		
		// Create goals
		for (int i = 0; i < goal_size; i ++) {
			goals.add(new Goal ("Type "+i, "Topic "+i));
		}
		
		// Create links
		links.add(new Link( goals.get(1), goals.get(0), Contribution.Make, Label.Satisficed) );
		links.add(new Link( goals.get(2), goals.get(0), Contribution.Make, Label.Satisficed) );
		links.add(new Link( goals.get(3), goals.get(0), Contribution.Make, Label.Satisficed) );
		links.add(new Link( goals.get(4), goals.get(2), Contribution.Make, Label.Satisficed) );
		links.add(new Link( goals.get(5), goals.get(3), Contribution.Make, Label.Satisficed) );
		links.add(new Link( goals.get(6), goals.get(3), Contribution.Make, Label.Satisficed) );
		links.add(new Link( goals.get(6), goals.get(8), Contribution.Make, Label.Satisficed) );
		links.add(new Link( goals.get(8), goals.get(7), Contribution.Make, Label.Satisficed) );
		links.add(new Link( goals.get(9), goals.get(7), Contribution.Make, Label.Satisficed) );
		
		// update links to softgoals
		for (Link link : links) {
			link.updateChildAndParent();
		}
		
		propagator = new Propagator(goals);
		propagator.start();

	}

}
