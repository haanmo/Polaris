import java.io.IOException;
import java.util.List;

public class Propagator {
	
	Display display = new Display();
	List<Goal> goals = null;
	
	Propagator() {}
	
	Propagator (List<Goal> goals) {
		this.goals = goals;
		display.printGoals(this.goals); 
	}

	public void start() {
		// TODO Auto-generated method stub
		
		// propagate 
		for (Goal goal : goals) {
			propagate_dfs(goal);
		}
		
	}
	
	private boolean propagate_dfs(Goal goal) {
		if (goal.labeled) return true;
		
		// check children 
		for (Goal sub : goal.getChildGoals()) {
			propagate_dfs(sub);
			sub.labeled = true;
			
			display.printGoals(this.goals);
		}
		
		goal.labeled = true;
		
		System.out.println();
		System.out.println("##### Labeling - " + goal.type + " " + goal.topic + " #####");
		System.out.println();
		
		try {
			System.in.read();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	//private boolean decideLabel
}
