import java.util.*;

public class StiringNumber {

	public static void main(String[] args) {		
		// n, k -> stiring numbers.
		//		n: the number of services. 		k the number of containers.
		// a stiring number set-> design options.
		
		// 1. n, k -> a list of stiring numbers
		//		e.g., n=6, k=3 -> (1, 1, 4), (1, 2, 3), (1, 3, 2), (1, 4, 1), 	(2, 1, 3), 	(2, 2, 2), (2, 3, 1)
		// 2. a stiring number  -> combinations
		//		e.g., (2, 1, 3) -> {(1,2), (3), (4,5,6)}, {(1,3), (2), (4,5,6)}, ..., {(2,3), (1), (4,5,6)}, ...
		
		int Ns = 4, Nc = 3;
		List<List<Integer>> stirlingSet = new ArrayList<>();
		List<List<List<Integer>>> designOptions = new ArrayList<>();
		
		
		// generate stiring numbers
		getStiringNumbers(Ns, Nc, new ArrayList<Integer>(), stirlingSet);
		
		// generate design options
		for (List<Integer> stiring : stirlingSet) {
			System.out.println("current stiring: " + stiring);
			Set<Integer> svcSet = new HashSet<>();
			for (int svc = 1; svc <= Ns; svc++) svcSet.add(svc);
			getDesignOptions(stiring, 0, svcSet, Ns, new ArrayList<List<Integer>>(), designOptions);
		}
		System.out.println(designOptions.size());
		
	}

	
	private static void getDesignOptions (List<Integer> stiring, int stiringIdx, Set<Integer> svcSet, int n, List<List<Integer>> current, List<List<List<Integer>>> designOptions) {
		// 2. a stiring number  -> combinations
		// e.g., (2, 1, 3) -> {(1,2), (3), (4,5,6)}, {(1,3), (2), (4,5,6)}, ..., {(2,3), (1), (4,5,6)}, ...
		
		if (stiringIdx == stiring.size()) {
			System.out.println(current);
			designOptions.add(new ArrayList<>(current));
			return;
		}
		
		List<List<Integer>> currentCombinations = new ArrayList<>();
		getCombinations(svcSet, n, stiring.get(stiringIdx), 1, new ArrayList<Integer>(),  currentCombinations);
		
		for (List<Integer> combination : currentCombinations) {
			current.add(combination);
			for (int i = 0; i < combination.size(); i++) svcSet.remove(combination.get(i));
			getDesignOptions(stiring, stiringIdx + 1, svcSet, n, current, designOptions);
			current.remove(current.size() - 1);
			for (int i = 0; i < combination.size(); i++) svcSet.add(combination.get(i));
		}	
	}
	
	// among n sevices, select k services. nCk
	private static void getCombinations (Set<Integer> svcSet, int n, int k, int start, List<Integer> current, List<List<Integer>> combinations) {
		if (k == 0) {
			combinations.add(new ArrayList<>(current));
			return;
		}
			
		for (int svc = start; svc <= n; svc++) {
			if (svcSet.contains(svc)) {
				current.add(svc);
				svcSet.remove(svc);
				getCombinations(svcSet, n, k - 1, svc + 1, current, combinations);
				current.remove(current.size() - 1);
				svcSet.add(svc);
			}
		}
	}
	
	// backtracking (remained n, remaind k, start, current, stirling)
	private static void getStiringNumbers(int n, int k, List<Integer> current, List<List<Integer>> stirlingSet) {
		if (k == 0) {
			stirlingSet.add(new ArrayList<>(current));
			return;
		}
		
		for (int i = 1; i <= n-k+1; i++) {
			if (k == 1) current.add(n);
			else current.add(i);
			getStiringNumbers(n - i, k - 1, current, stirlingSet);
			current.remove(current.size() - 1);
			if (k == 1) break;
		}
	}
	
	
	
}
