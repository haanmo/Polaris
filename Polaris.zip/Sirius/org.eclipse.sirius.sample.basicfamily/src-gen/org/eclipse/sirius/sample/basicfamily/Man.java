/**
 */
package org.eclipse.sirius.sample.basicfamily;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Man</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.sirius.sample.basicfamily.BasicfamilyPackage#getMan()
 * @model
 * @generated
 */
public interface Man extends Person {
} // Man
