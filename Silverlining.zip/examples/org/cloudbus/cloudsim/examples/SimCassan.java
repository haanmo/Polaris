
/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation
 *               of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009, The University of Melbourne, Australia
 */


package org.cloudbus.cloudsim.examples;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicySimple;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

/**
 * An example showing how to create
 * scalable simulations.
 */
public class SimCassan {

	/** The cloudlet list. */
	private static List<Cloudlet> cloudletList;

	/** The vmlist. */
	private static List<Vm> vmlist;
		
	static int servers=9;
	static int users=920;
	static int currentMips=0;
	private static List<Vm> createVM(int userId, int vms) {

		//Creates a container to store VMs. This list is passed to the broker later
		LinkedList<Vm> list = new LinkedList<Vm>();
				
		//VM Parameters
		int mips = 1063;
		long size = 10000; //image size (MB)
		int ram = 7680; //vm memory (MB)
		long bw = 1000000;
		int pesNumber = 4; //number of cpus
		String vmm = "Xen"; //VMM name21.98

		
		//3node 2 dimension
		//mips= (int)(-0.0004*Math.pow(users, 2) - 0.0257*users + 1162.5);
		
		//mips= (int)(0.0013*Math.pow(users, 3) - 0.4006*Math.pow(users, 2) + 33.662*users + 544.1);
		//currentMips=mips;	
		
		// -0.0004*Math.pow(users, 2) - 0.0257*users + 1162.5
		// 0.0013*Math.pow(users, 3) - 0.4006*Math.pow(users, 2) + 33.662*users + 544.1
		
		
		//3node 3 dimension
		//mips= (int)(0.00000008*Math.pow(users, 3) - 0.0001*Math.pow(users, 2) - 0.1485*users + 861.41);
		//currentMips=mips;	
		// 0.00000008*Math.pow(users, 3) - 0.0001*Math.pow(users, 2) - 0.1485*users + 861.41	
		
		//3node 4 dimension
		//mips= (int)(-0.0000000001*Math.pow(users, 4) + 0.0000002*Math.pow(users, 3) - 0.00003*Math.pow(users, 2) - 0.0913*users + 524.61);
		//currentMips=mips;	
		
		// total test
		double m = (-95.54761905)*servers + (-1.257344083)*0.1*users + 1378.406238;
		mips = (int) m;
		currentMips=mips;
		/*
		int mips = 0;
		
		//Math.pow(��, ����);
		if(servers==3){
			mips=(int) (0.0223*Math.pow(users, 3)-9.3804*Math.pow(users, 2) +2000.9*Math.pow(users, 1) - 11053);
		}else if(servers==6){
			mips=(int) (0.0223*Math.pow(users, 3)-9.3804*Math.pow(users, 2) +2000.9*Math.pow(users, 1) - 11053);
		}else if(servers==9){
			mips=(int) (0.0223*Math.pow(users, 3)-9.3804*Math.pow(users, 2) +2000.9*Math.pow(users, 1) - 11053);
		}
		*/
		
		
		//create VMs
		Vm[] vm = new Vm[vms];

		for(int i=0;i<vms;i++){
			vm[i] = new Vm(i, userId, mips, pesNumber, ram, bw, size, vmm, new CloudletSchedulerTimeShared());
			//for creating a VM with a space shared scheduling policy for cloudlets:
			//vm[i] = Vm(i, userId, mips, pesNumber, ram, bw, size, priority, vmm, new CloudletSchedulerSpaceShared());

			list.add(vm[i]);
		}

		return list;
	}
	
	private static List<Cloudlet> createCloudlet(int userId, int cloudlets){
		// Creates a container to store Cloudlets
		LinkedList<Cloudlet> list = new LinkedList<Cloudlet>();

		//cloudlet parameters
		long length = 10000; //operationcount=400000. operationcount = length*cloudlets
		long fileSize = 300;
		long outputSize = 300;
		int pesNumber = 1;
		UtilizationModel utilizationModel = new UtilizationModelFull();

		Cloudlet[] cloudlet = new Cloudlet[cloudlets];

		for(int i=0;i<cloudlets;i++){
			cloudlet[i] = new Cloudlet(i, length, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
			// setting the owner of these Cloudlets
			cloudlet[i].setUserId(userId);
			list.add(cloudlet[i]);
		}

		return list;
	}


	////////////////////////// STATIC METHODS ///////////////////////

	/**
	 * Creates main() to run this example
	 */
	public static void main(String[] args) {
		Log.printLine("Starting CloudSimExample6...");

		long start = System.currentTimeMillis();
		String str = new String();
		//str.substring(arg0, arg1);
		try {
			// First step: Initialize the CloudSim package. It should be called
			// before creating any entities.
			int num_user = users;   // number of grid users
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = false;  // mean trace events

			// Initialize the CloudSim library
			CloudSim.init(num_user, calendar, trace_flag);

			// Second step: Create Datacenters
			//Datacenters are the resource providers in CloudSim. We need at list one of them to run a CloudSim simulation
			@SuppressWarnings("unused")
			Datacenter datacenter0 = createDatacenter("Datacenter_0");
			@SuppressWarnings("unused")
			Datacenter datacenter1 = createDatacenter("Datacenter_1");

			//Third step: Create Broker
			DatacenterBroker broker = createBroker();
			int brokerId = broker.getId();

			//Fourth step: Create VMs and Cloudlets and send them to broker
			vmlist = createVM(brokerId,servers); //creating 20 vms
			cloudletList = createCloudlet(brokerId,num_user); // creating 40 cloudlets

			broker.submitVmList(vmlist);
			broker.submitCloudletList(cloudletList);

			// Fifth step: Starts the simulation
			CloudSim.startSimulation();

			// Final step: Print results when simulation is over
			List<Cloudlet> newList = broker.getCloudletReceivedList();

			CloudSim.stopSimulation();

			printCloudletList(newList);

			Log.printLine("CloudSimExample6 finished!");
			
			long end = System.currentTimeMillis();
			System.out.println("Run Time: " + ( end - start )/1000.0);
			System.out.println("currentMips: "+currentMips);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			Log.printLine("The simulation has been terminated due to an unexpected error");
		}
	}

	private static Datacenter createDatacenter(String name){

		// Here are the steps needed to create a PowerDatacenter:
		// 1. We need to create a list to store one or more
		//    Machines
		List<Host> hostList = new ArrayList<Host>();

		// 2. A Machine contains one or more PEs or CPUs/Cores. Therefore, should
		//    create a list to store these PEs before creating
		//    a Machine.
		List<Pe> peList1 = new ArrayList<Pe>();

		//int mips = 499999999;
		int mips = 536800000; //peList�� �þ���� �̰� ���� �۾ƾ���. ����? 4���϶��� 536800000 ���� ���� 

		// 3. Create PEs and add these into the list.
		//for a quad-core machine, a list of 4 PEs is required:
		peList1.add(new Pe(0, new PeProvisionerSimple(mips))); // need to store Pe id and MIPS Rating
		peList1.add(new Pe(1, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(2, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(3, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(4, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(6, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(7, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(8, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(9, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(10, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(11, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(12, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(13, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(14, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(15, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(16, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(17, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(18, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(19, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(20, new PeProvisionerSimple(mips)));

		//4. Create Hosts with its id and list of PEs and add them to the list of machines
		int hostId=0;
		int ram = 53680000; //host memory (MB)
		long storage = 536800000; //host storage
		int bw = 53680000;

		hostList.add(
    			new Host(
    				hostId,
    				new RamProvisionerSimple(ram),
    				new BwProvisionerSimple(bw),
    				storage,
    				peList1,
    				new VmSchedulerTimeShared(peList1)
    			)
    		); // This is our first machine

		hostId++;


		// 5. Create a DatacenterCharacteristics object that stores the
		//    properties of a data center: architecture, OS, list of
		//    Machines, allocation policy: time- or space-shared, time zone
		//    and its price (G$/Pe time unit).
		String arch = "x86";      // system architecture
		String os = "Linux";          // operating system
		String vmm = "Xen";
		double time_zone = 10.0;         // time zone this resource located
		double cost = 3.0;              // the cost of using processing in this resource
		double costPerMem = 0.05;		// the cost of using memory in this resource
		double costPerStorage = 0.1;	// the cost of using storage in this resource
		double costPerBw = 0.1;			// the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>();	//we are not adding SAN devices by now

		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                arch, os, vmm, hostList, time_zone, cost, costPerMem, costPerStorage, costPerBw);


		// 6. Finally, we need to create a PowerDatacenter object.
		Datacenter datacenter = null;
		try {
			datacenter = new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return datacenter;
	}

	//We strongly encourage users to develop their own broker policies, to submit vms and cloudlets according
	//to the specific rules of the simulated scenario
	private static DatacenterBroker createBroker(){

		DatacenterBroker broker = null;
		try {
			broker = new DatacenterBroker("Broker");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}

	/**
	 * Prints the Cloudlet objects
	 * @param list  list of Cloudlets
	 * @throws IOException 
	 */
	private static void printCloudletList(List<Cloudlet> list) throws IOException {
		int size = list.size();
		Cloudlet cloudlet;

		FileWriter fw = new FileWriter("output.txt");
		BufferedWriter bw = new BufferedWriter(fw);
        		
		String indent = "    ";
		Log.printLine();
		Log.printLine("========== OUTPUT ==========");
		Log.printLine("Cloudlet ID" + indent + "STATUS" + indent +
				"Data center ID" + indent + "VM ID" + indent + indent + "Time" + indent + "Start Time" + indent + "Finish Time");

		bw.write("========== OUTPUT ==========\r\n");		
		bw.write("Cloudlet ID" + indent + "STATUS" + indent +
				"Data center ID" + indent + "VM ID" + indent + indent + "Time" + indent + "Start Time" + indent + "Finish Time\r\n");

		
		DecimalFormat dft = new DecimalFormat("###.##");
		for (int i = 0; i < size; i++) {
			cloudlet = list.get(i);
			Log.print(indent + cloudlet.getCloudletId() + indent + indent);

			if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS){
				Log.print("SUCCESS");

				Log.printLine( indent + indent + cloudlet.getResourceId() + indent + indent + indent + cloudlet.getVmId() +
						indent + indent + indent + dft.format(cloudlet.getActualCPUTime()) +
						indent + indent + dft.format(cloudlet.getExecStartTime())+ indent + indent + indent + dft.format(cloudlet.getFinishTime()));
				
				bw.write(indent + indent + cloudlet.getResourceId() + indent + indent + indent + cloudlet.getVmId() +
						indent + indent + indent + dft.format(cloudlet.getActualCPUTime()) +
						indent + indent + dft.format(cloudlet.getExecStartTime())+ indent + indent + indent + dft.format(cloudlet.getFinishTime())+"\r\n");
				
			}
		}
		
	}
}
