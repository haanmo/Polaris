import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.table.DefaultTableModel;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Ontology {
	//String[] ontologies = null;
	//float[] weights = null;
	//String[] values = null;
	boolean debug = true;
	
	ArrayList<String> ontologies = new ArrayList<String>();
	ArrayList<Float> weights = new ArrayList<Float>();
	ArrayList<String> values = new ArrayList<String>();
	File file2 = null;
	File file = null;

	int cntOntology = 0;

	Ontology() {
	}

	public int saveModel(DefaultTableModel table) {
		if (file == null) System.out.println("saveModel() Todo: taking null file");
		if (table == null) System.out.println("saveModel() Todo: taking null table");
		
		ontologies.clear();
		weights.clear();
		values.clear();
		cntOntology = 0;
				
		for (int i = 0; i < table.getRowCount(); i++) {
			ontologies.add( (String) table.getValueAt(i, 1) );
			weights.add( Float.valueOf( (String) table.getValueAt(i, 2)) );
			values.add( (String) table.getValueAt(i, 3) );
			cntOntology++;
		}
		
		// parse into JSON
		JSONObject obj = new JSONObject();
		JSONArray ontologyList = new JSONArray();
		JSONObject[] eachOntology = new JSONObject[cntOntology];

		for (int i = 0; i < cntOntology; i++) {
			eachOntology[i] = new JSONObject();
			eachOntology[i].put("Name", ontologies.get(i));
			eachOntology[i].put("Weight", weights.get(i));
			eachOntology[i].put("Value", values.get(i));
			ontologyList.add(eachOntology[i]);
		}
		obj.put("Ontology", ontologyList);

		try (FileWriter file = new FileWriter("model1.json")) {
			file.write(obj.toJSONString());
			file.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return 0;
	}
	public int readModel(File file) {

		this.file = file;
		String[] ext = file.getName().split("\\.");
		if (ext[ext.length - 1].equals("txt"))
			readModelfromTXT(file);
		else if (ext[ext.length - 1].equals("json"))
			readModelfromJSON(file);

		return 0;
	}
 
	public int readModelfromJSON(File file) {

		this.file = file;
		JSONParser parser = new JSONParser();

		try {
			// get JSON object
			Object obj = parser.parse(new FileReader(file.getAbsolutePath()));
			JSONObject jsonObject = (JSONObject) obj;
			JSONArray ontoList = (JSONArray) jsonObject.get("Ontology");

			// get line count
			cntOntology = ontoList.size();

			
			if (debug) System.out.println ("\n" + "* Read Ontologies from JSON");
			if (debug) System.out.println ("\t " + "Index" + "\t" + "Name" + "\t" + "Weight" + "\t" + "Value");
			//get each value
			for (int i = 0; i < cntOntology; i++) {
				JSONObject eachOntology = (JSONObject) ontoList.get(i);
				String nameTemp = (String) eachOntology.get("Name");
				float weightTemp = (float) (double) eachOntology.get("Weight");
				String valueTemp = (String) eachOntology.get("Value"); 
				
				ontologies.add(nameTemp);
				weights.add(weightTemp);
				values.add(valueTemp);
				
				if (debug) System.out.println ("\t " + i + "\t" + nameTemp + "\t" + weightTemp + "\t" + valueTemp);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public int readModelfromTXT(File file) {

		this.file = file;
		String fileName = this.file.toString();
		String line = null;

		int cntLines = 0;

		try {
			// FileReader reads text files in the default encoding.
			FileReader fileReader = new FileReader(fileName);

			// Always wrap FileReader in BufferedReader.
			BufferedReader bufferedReader = new BufferedReader(fileReader);

			// get line count
			line = bufferedReader.readLine();
			cntLines = Integer.parseInt(line);
			cntOntology = cntLines;

			// allocate arrays
			//ontologies = new String[cntLines];
			//weights = new float[cntLines];
			//values = new String[cntLines];

			// get ontologies
			for (int i = 0; i < cntLines; i++) {
				line = bufferedReader.readLine();
				//ontologies[i] = line;
				ontologies.add(line);
			}

			// get weights
			for (int i = 0; i < cntLines; i++) {
				line = bufferedReader.readLine();
				//weights[i] = Integer.parseInt(line);
				//weights[i] = Float.parseFloat(line);
				weights.add(Float.parseFloat(line));
			}

			// get values
			for (int i = 0; i < cntLines; i++) {
				line = bufferedReader.readLine();
				//values[i] = line;
				values.add(line);
			}

			for (int i = 0; i < cntLines; i++) {
				System.out.println(ontologies.get(i) + " || " + weights.get(i) + " || " + values.get(i));
			}

			// Always close files.
			bufferedReader.close();
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + fileName + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + fileName + "'");
			// Or we could just do this:
			ex.printStackTrace();
		}

		return 0;
	}

}
