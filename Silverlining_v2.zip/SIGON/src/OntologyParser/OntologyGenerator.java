package OntologyParser;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class OntologyGenerator {
	
	//   /Users/haanmo/test/model1.txt
	String[] names = null;
	float[] weights = null;
	String[] values = null;
	int cntOntologies = 0;
	
	private int readFromTxt(String path) {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		String line = null;
		
		// get names and weights from a file
		try {
			// Always wrap FileReader in BufferedReader.
			FileReader fileReader = new FileReader(path);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
            
			// get the number of ontologies 
            line = bufferedReader.readLine();
            cntOntologies = Integer.parseInt(line);
            
            //allocate arrays
            names = new String[cntOntologies];
            weights = new float[cntOntologies];
            values = new String[cntOntologies];
            
            //get ontologies
            for(int i=0; i<cntOntologies; i++) {
            		line = bufferedReader.readLine();
            		names[i] = line;
            }
            
            //get weights
            for(int i=0; i<cntOntologies; i++) {
            		line = bufferedReader.readLine();
            		weights[i] = Float.parseFloat(line);
            }
            
          //get values
            for(int i=0; i<cntOntologies; i++) {
            		line = bufferedReader.readLine();
            		values[i] = line;
            }
            
            ///// print
            for(int i=0; i<cntOntologies; i++) {
        			System.out.println(names[i] + " | " + weights[i] + " | " + values[i]);
            }
        
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return 0;
	}
	
	private int writeJSON(String path) {
		// parse into JSON
		JSONObject obj = new JSONObject();
		JSONArray ontologyList = new JSONArray();
		JSONObject[] eachOntology = new JSONObject[cntOntologies];
				
		for (int i = 0; i < cntOntologies; i++) {
			eachOntology[i] = new JSONObject();
			eachOntology[i].put("Name", names[i]);
			eachOntology[i].put("Weight", weights[i]);
			eachOntology[i].put("Value", values[i]);
			ontologyList.add(eachOntology[i]);
		}
		obj.put("Ontology", ontologyList);
				
		try (FileWriter file = new FileWriter(path)) {
			file.write(obj.toJSONString());
			file.flush();
		}catch (IOException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	int generateOntology () {
		
		readFromTxt("/Users/haanmo/test/model1.txt");
		writeJSON("model1.json");
		
		readFromTxt("/Users/haanmo/test/model2.txt");
		writeJSON("model2.json");
		
		return 0;
	}
	
}
