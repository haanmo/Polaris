import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class Panel {
	protected JPanel instancePanel = null;
	protected String paneltype;
	protected int id;
	
	public Panel(String type, int id) {
		this.id = id;
		paneltype = type;
	}
	
	public JPanel getInstancePanel () {
		return instancePanel;
	}
	
	public String getPanelType () {
		return paneltype;
	}
}
