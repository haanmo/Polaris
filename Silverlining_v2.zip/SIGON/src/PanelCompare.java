import java.awt.BorderLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.lang.invoke.ConstantCallSite;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.filechooser.FileSystemView;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class PanelCompare extends Panel {

	private static final int TEXTPANE_TOP = 0;
	private static final int TEXTPANE_BOTTOM = 1;
	private static final int TABLE_LEFT = 0;
	private static final int TABLE_RIGHT = 1;
	private static final int TABLE_MIDDLE = 2;
	private static final int NUM_COLUMNS_LR = 4;
	private static final int NUM_COLUMNS_MID = 3;

	private JTextPane[] textPane = null;
	private JTable[] tableModels = null;
	private JTable tableRule;
	private File[] ontologyFiles = null;
	private File ruleFile = null;

	private Ontology[] ontologyModels = null;
	private Rule rule = null;
	private boolean debug = true;

	public PanelCompare(String type, int id) {
		super(type, id);

		// TODO Auto-generated constructor stub
		ontologyModels = new Ontology[2];
		for (int i = 0; i < 2; i++)
			ontologyModels[i] = new Ontology();
		rule = new Rule(); // just in case

		//
		tableModels = new JTable[3];
		textPane = new JTextPane[2];
		ontologyFiles = new File[2];

		instancePanel = new JPanel();
		instancePanel.setLayout(null);

		////////////////////
		/////// Tables
		////////////////////

		Object columnNames[] = { "Select", "Ontology", "Weight", "Value" };
		tableModels[0] = createTableModel(columnNames, 6, 245, 325, 285);
		tableModels[1] = createTableModel(columnNames, 509, 245, 325, 285);

		Object columnNames2[] = { "Select", "Rule", "Satisficied" };
		tableModels[2] = createTableModel(columnNames2, 353, 245, 133, 285);

		//////
		/*
		 * tableModels[0].addMouseListener(new java.awt.event.MouseAdapter() {
		 * 
		 * @Override public void mouseClicked(java.awt.event.MouseEvent evt) { int row =
		 * tableModels[0].rowAtPoint(evt.getPoint()); int col =
		 * tableModels[0].columnAtPoint(evt.getPoint()); System.out.println(row + " " +
		 * col);
		 * 
		 * //if (row >= 0 && col >= 0) { //}
		 * 
		 * } });
		 */
		/////

		////////////////////
		//////// Text Planel
		////////////////////

		textPane[0] = createTextPane(7, 38, 828, 165);
		textPane[1] = createTextPane(4, 568, 830, 73);

		////////////////////
		/////// Labels
		////////////////////

		createLabels("Mapping Output Screen", 6, 16, 250, 16);
		createLabels("Ontologies of Model 1", 6, 222, 250, 16);
		createLabels("Ontologies of Model 2", 509, 223, 233, 16);
		createLabels("Mapping Rules", 353, 223, 133, 16);
		createLabels("Mapping Equation", 4, 546, 287, 16);

	}

	JTextPane createTextPane(int x, int y, int w, int h) {

		JTextPane textPane = new JTextPane();
		JScrollPane scrollPane_textPane = new JScrollPane(textPane);
		scrollPane_textPane.setBounds(x, y, w, h);
		instancePanel.add(scrollPane_textPane);

		return textPane;
	}

	Label createLabels(String str, int x, int y, int w, int h) {

		Label label = new Label(str);
		label.setBounds(x, y, w, h);
		instancePanel.add(label);

		return label;
	}

	JTable createTableModel(Object[] columnNames, int x, int y, int w, int h) {

		// Object rowData[][] = {{Boolean.FALSE, "", "",""}};
		Object rowData[][] = {};
		TableModel tmTemp = new DefaultTableModel(rowData, columnNames);

		JTable tableModel = new JTable(tmTemp) {
			public boolean isCellEditable(int nRow, int nCol) {
				return true;
			}

			@Override
			public Class<?> getColumnClass(int columnIndex) {
				if (columnIndex == 0) {
					return getValueAt(0, 0).getClass();
				}
				return super.getColumnClass(columnIndex);
			}

		};

		DefaultTableModel contactTableModel = (DefaultTableModel) tableModel.getModel();
		contactTableModel.setColumnIdentifiers(columnNames);
		// tableModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		JScrollPane scrollPane_tableModel = new JScrollPane(tableModel);
		scrollPane_tableModel.setBounds(x, y, w, h);
		instancePanel.add(scrollPane_tableModel);

		return tableModel;
	}

	int loadOntology(int tableNumber) {
		File selectedFile = null;
		JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());

		int returnValue = jfc.showOpenDialog(null);

		if (returnValue == JFileChooser.APPROVE_OPTION) {
			selectedFile = jfc.getSelectedFile();
		}

		if (tableNumber == TABLE_LEFT || tableNumber == TABLE_RIGHT) {
			ontologyFiles[tableNumber] = selectedFile;
			ontologyModels[tableNumber].readModel(selectedFile);
		} else {
			ruleFile = selectedFile;
			rule.readModel(ontologyModels, selectedFile);
		}

		int updated = updateTable(tableNumber);
		
		if (tableNumber == TABLE_MIDDLE) {
			updateTextPane (TEXTPANE_TOP);
		}

		return 0;
	}

	int updateTable(int tableNumber) {
		
		// DefaultTableModel tableModel = (DefaultTableModel) tableModel1.getModel();

		DefaultTableModel defaultTableModel = null;
		defaultTableModel = (DefaultTableModel) tableModels[tableNumber].getModel();

		// remove existing table data.
		int rowCount = defaultTableModel.getRowCount();
		for (int i = 0; i < rowCount; i++) {
			defaultTableModel.removeRow(0);
		}

		// add data
		if (tableNumber == TABLE_LEFT || tableNumber == TABLE_RIGHT) {
			int ontologyCount = ontologyModels[tableNumber].cntOntology;
			Object[] obj = new Object[NUM_COLUMNS_LR];
			for (int i = 0; i < ontologyCount; i++) {
				obj[0] = Boolean.FALSE;
				obj[1] = ontologyModels[tableNumber].ontologies.get(i);
				obj[2] = String.valueOf(ontologyModels[tableNumber].weights.get(i));
				obj[3] = ontologyModels[tableNumber].values.get(i);
				defaultTableModel.addRow(obj);
			}
			tableModels[tableNumber].setModel(defaultTableModel);
		} else {
			int ruleCount = rule.cntRules;
			Object[] obj = new Object[NUM_COLUMNS_MID];
			for (int i = 0; i < ruleCount; i++) {
				obj[0] = Boolean.FALSE;
				obj[1] = Integer.valueOf(i);
				obj[2] = String.valueOf(rule.satisfice.get(i));
				defaultTableModel.addRow(obj);
				
			}

		}
		return 0;
	}

	int addRow(int tableNumber) {
		DefaultTableModel table = (DefaultTableModel) tableModels[tableNumber].getModel();
		if (tableNumber == TABLE_LEFT || tableNumber == TABLE_RIGHT) {
			table.addRow(new Object[] { Boolean.FALSE, "", "", "" });
		} else if (tableNumber == TABLE_MIDDLE) {
			table.addRow(new Object[] { Boolean.FALSE, "", "" });
		}
		ontologyModels[tableNumber].cntOntology++;
		return 0;
	}

	int saveModel(int tableNumber) {
		// save all the element in a table to the list
		DefaultTableModel table = (DefaultTableModel) tableModels[tableNumber].getModel();
		ontologyModels[tableNumber].saveModel(table);
		int updated = updateTable(tableNumber);
		return 0;
	}
	
	int updateTextPane(int textPaneNumber) {
		
		if ( textPaneNumber == TEXTPANE_TOP) {
			String str = "";
			str += "1. Missing Ontologies" + "\n";
			
			if (debug) System.out.println ("\n"+ "* Print Missing Ontologies");
			if (debug) System.out.println ("\t"+ "i" + "\t" + "missingIndex" + "\t" + "missingOntology");
			
			for (int i = 0; i < rule.missingOnologies_model_1.size(); i ++) {
				int missingIndex = rule.missingOnologies_model_1.get(i);
				String missingOntology = ontologyModels[0].ontologies.get(missingIndex);
				
				str += "\t" + missingOntology + "\n";
				
				if (debug) System.out.println ("\t"+ i + "\t" + missingIndex + "\t" + missingOntology);
			}
			str += "\n";
			str += "2. Similarity" + "\n";
			
			str += "\t" + rule.similarity_model_1 + "\n";
			
			textPane[TEXTPANE_TOP].setText(str);
		} else {
			
		}
		
		return 0;
	}
}
