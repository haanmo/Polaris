import java.awt.BorderLayout;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.filechooser.FileSystemView;

public class PanelDiagram extends Panel {
	
	private boolean imageLoaded = false;  

	public PanelDiagram(String type, int id) {
		super(type, id);
		// TODO Auto-generated constructor stub
		
		instancePanel = new JPanel();
		JLabel labelTemp = new JLabel(type + " " + id + " Tab", SwingConstants.LEFT);
		instancePanel.add(labelTemp);
		
		if ( isImageLoaded() == false) {
			if (type.equals("SIG")) loadImage();
			else if (type.equals("Ontology")) loadImage();
		}
		
	}
	
	public int loadImage() {
		
		File selectedFile = null;
		JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());

		int returnValue = jfc.showOpenDialog(null);

		if (returnValue == JFileChooser.APPROVE_OPTION) {
			selectedFile = jfc.getSelectedFile();
			//System.out.println(selectedFile.getAbsolutePath());
		}
		
		ImageIcon image = new ImageIcon(selectedFile.toString());
		JLabel label = new JLabel(null, image, JLabel.CENTER);
		instancePanel.add(label, BorderLayout.CENTER);
		imageLoaded = true;
		return 0;
	}
	
	public boolean isImageLoaded () {
		return imageLoaded;
	}

}
