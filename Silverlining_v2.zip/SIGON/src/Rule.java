import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;

import javax.swing.text.html.HTMLDocument.HTMLReader.IsindexAction;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/*

Todo: 
	1) missing ontologies
	2) similarity
	3) update tab
 
*/

/*

1. JSON
	
	1) model 1 & 2 file paths
	2) parent rule file path
	3) Rule
	 	{
	 		ontology in model1: 0,1
	 		ontology in model 2: 0,1
	 		satisfice: 5
	 		eq: conc = conc
	 	},
	 	{
	 		ontology in model1:
	 		ontology in model 2:
	 		satisfice
	 		eq:
	 	}
	 	
	 4) similarity
	
2. In program
	
	1) each ontologies
	2) missing ontologies
	3) similarity
	
3. Usage
	
	1) load
	2) new 
	
 */

/*

{
	"Ontology":
	[
		{"Value":"","Weight":2.0,"Name":"Concurrent User"},
		{"Value":"","Weight":1.0,"Name":"Arrival Rate"},
		{"Value":null,"Weight":1.0,"Name":"Transaction Class"},
		{"Value":null,"Weight":1.0,"Name":"Transaction Size"},
		{"Value":null,"Weight":1.0,"Name":"Transaction Type"},
		{"Value":null,"Weight":3.0,"Name":"Data Size"},
		{"Value":null,"Weight":2.0,"Name":"Data Request Distribution"},
		{"Value":null,"Weight":2.0,"Name":"Data Distribution"},
		{"Value":null,"Weight":1.0,"Name":"Network Model"},
		{"Value":null,"Weight":4.0,"Name":"Cluster Size"},
		{"Value":null,"Weight":2.0,"Name":"Server Type"},
		{"Value":null,"Weight":3.0,"Name":"#CPU"},
		{"Value":null,"Weight":4.0,"Name":"Clock Speed"},
		{"Value":null,"Weight":2.0,"Name":"Memory Size"},
		{"Value":null,"Weight":3.0,"Name":"Database Type"},
		{"Value":null,"Weight":3.0,"Name":"Storage Type"}
	]
}

{
	"Ontology":
		[
			{"Value":"Client Thread","Weight":2.0,"Name":"Client Thread"},
			{"Value":"Uniform_distribution","Weight":1.0,"Name":"Arrival Rate"},
			{"Value":"Database_Operation","Weight":1.0,"Name":"Transaction Class"},
			{"Value":"Database_Operation_Count","Weight":1.0,"Name":"Transaction Size"},
			{"Value":"Read, Update, Scan, Insert","Weight":1.0,"Name":"Transaction Type"},
			{"Value":"Data Size","Weight":3.0,"Name":"Data Size"},
			{"Value":"Uniform, Zipfian, Latest, Multinomial","Weight":2.0,"Name":"Data Request Distribution"},
			{"Value":"N\/A","Weight":2.0,"Name":"Data Distribution"},
			{"Value":"Network_model","Weight":1.0,"Name":"Network Model"},
			{"Value":"Cluster Size","Weight":4.0,"Name":"Cluster Size"},
			{"Value":"Server Type","Weight":2.0,"Name":"Server Type"},
			{"Value":"#CPU","Weight":3.0,"Name":"#CPU"},
			{"Value":"Clock Speed","Weight":4.0,"Name":"Clock Speed"},
			{"Value":"Memory Size","Weight":2.0,"Name":"Memory Size"},
			{"Value":"Database Type","Weight":3.0,"Name":"Database Type"},
			{"Value":"Storage Type","Weight":3.0,"Name":"Storage Type"}
		]
}
 */

public class Rule {

	private static final int MODEL_1 = 0;
	private static final int MODEL_2 = 1;
	private static final int numModels = 2;

	File ruleFile = null;
	String[] filePath = null;
	String parentRulePath = null;
	Ontology[] ontology = null; // 0: left table ontology, 1: right table ontology
	Ontology missingOntology = null;
	float similarity = 0;

	ArrayList<ArrayList<Integer>> onto_in_model_1 = null;
	ArrayList<ArrayList<Integer>> onto_in_model_2 = null;
	ArrayList<ArrayList<Float>> satisfice = null;
	ArrayList<String> equation = null;

	HashMap<Integer, Integer> coveredOntology_model_1 = null;
	HashMap<Integer, Integer> coveredOntology_model_2 = null;
	
	ArrayList<Integer> missingOnologies_model_1 = null;
	ArrayList<Integer> missingOnologies_model_2 = null;

	int cntRules = 0;
	int cntFiles = 0;
	
	float maxWeight_ontology = 0;
	float maxWeight_relation = 0;
	
	public float parentSimilarity = 0;
	public float similarity_model_1 = 0;
	public float similarity_model_2 = 0;
	

	public Rule() {
		// TODO Auto-generated constructor stub
		filePath = new String[numModels];
		ontology = new Ontology[numModels];
		for (int i = 0; i < numModels; i++) {
			filePath[i] = new String(); // just in case
			ontology[i] = new Ontology(); // just in case
		}

		onto_in_model_1 = new ArrayList<ArrayList<Integer>>();
		onto_in_model_2 = new ArrayList<ArrayList<Integer>>();
		satisfice = new ArrayList<ArrayList<Float>>();
		equation = new ArrayList<String>();

		coveredOntology_model_1 = new HashMap<Integer, Integer>();
		coveredOntology_model_2 = new HashMap<Integer, Integer>();
		
		missingOnologies_model_1 = new ArrayList<Integer>();
		missingOnologies_model_2 = new ArrayList<Integer>();
		
		maxWeight_ontology = 5;
		maxWeight_relation = 5;
	}

	public int readModel(Ontology[] models, File file) {

		ontology[0] = models[0];
		ontology[1] = models[1];
		this.ruleFile = file;

		String[] ext = file.getName().split("\\.");
		if (ext[ext.length - 1].equals("txt"))
			;
		// readModelfromTXT(file);
		else if (ext[ext.length - 1].equals("json"))
			readModelfromJSON(file);
		
		getMissingOntologies();
		getSimilarity();
		
		return 0;
	}

	public int readModelfromJSON(File file) {

		this.ruleFile = file;
		JSONParser parser = new JSONParser();

		try {

			// get JSON object
			Object obj = parser.parse(new FileReader(file.getAbsolutePath()));
			JSONObject jsonObject = (JSONObject) obj;

			// 1. Get File list

			// Get JSON object
			JSONArray fileList = (JSONArray) jsonObject.get("File");

			// Get line count
			cntFiles = fileList.size();

			// get each file path
			for (int i = 0; i < cntFiles; i++) {
				filePath[i] = (String) fileList.get(i);
			}

			// 2. Get Mapping Rules

			///////////////////////////////
			// Get JSON object
			JSONArray ruleList = (JSONArray) jsonObject.get("Rule");
			cntRules = ruleList.size();
		
			for (int i = 0; i < cntRules; i++) {
				JSONObject eachRule = (JSONObject) ruleList.get(i);

				// get model 1 ontologies
				JSONArray onto_1_List = (JSONArray) eachRule.get("Model_1");
				ArrayList<Integer> onto_1_arr = new ArrayList<Integer>();
				for (int j = 0; j < onto_1_List.size(); j++) {
					Iterator<String> iterTemp = onto_1_List.iterator();
					while (iterTemp.hasNext()) {
						Integer idx = Integer.valueOf(iterTemp.next());
						onto_1_arr.add(idx);
						if (coveredOntology_model_1.containsKey(idx)) 
							coveredOntology_model_1.put (idx, coveredOntology_model_1.get(idx)+1);
						else 
							coveredOntology_model_1.put (idx, 1);
					}
				}
				onto_in_model_1.add(onto_1_arr);

				// coveredOntology_model_1

				// get model 2 ontologies
				JSONArray onto_2_List = (JSONArray) eachRule.get("Model_2");
				ArrayList<Integer> onto_2_arr = new ArrayList<Integer>();
				for (int j = 0; j < onto_2_List.size(); j++) {
					Iterator<String> iterTemp = onto_2_List.iterator();
					while (iterTemp.hasNext()) {
						Integer idx = Integer.valueOf(iterTemp.next());
						onto_2_arr.add(idx);
						if (coveredOntology_model_2.containsKey(idx)) 
							coveredOntology_model_2.put (idx, coveredOntology_model_2.get(idx)+1);
						else 
							coveredOntology_model_2.put (idx, 1);
					}
				}
				onto_in_model_2.add(onto_2_arr);

				// get satisficing list
				//satisfice.add(Float.valueOf((String) eachRule.get("Satisficing")));
				JSONArray satisfice_List = (JSONArray) eachRule.get("Satisficing");
				ArrayList<Float> satisfice_arr = new ArrayList<Float>();
				for (int j = 0; j < onto_2_List.size(); j++) {
					Iterator<String> iterTemp = satisfice_List.iterator();
					while (iterTemp.hasNext()) {
						Float degree = Float.valueOf(iterTemp.next());
						satisfice_arr.add(degree);
					}
				}
				satisfice.add(satisfice_arr);

				// get equation list
				equation.add((String) eachRule.get("Equation"));
			}

			/*
			System.out.println ("------------------");
			for (int i = 0; i < cntRules; i++) {
				System.out.println("\t" + onto_in_model_1.get(i));
				System.out.println("\t" + onto_in_model_2.get(i));
				System.out.println("\t" + satisfice.get(i));
				System.out.println("\t" + equation.get(i));
			}
			
			for(Entry<Integer, Integer> entry : coveredOntology_model_1.entrySet()) {
			    Integer key = entry.getKey();
			    Integer value = entry.getValue();
			    System.out.println("\t coveredOntology_model_1 "+ key + " " + value);
			}
			
			for(Entry<Integer, Integer> entry : coveredOntology_model_2.entrySet()) {
			    Integer key = entry.getKey();
			    Integer value = entry.getValue();
			    System.out.println("\t coveredOntology_model_2 "+ key + " " + value);
			}
			*/

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	int getMissingOntologies () {
		
		// get missing ontologies of model 1
		//System.out.println ("======================");
		//System.out.println ("ontology[0].cntOntology" + ontology[0].cntOntology);
		
		for (int i = 0; i < ontology[0].cntOntology; i++) {
			if (!coveredOntology_model_1.containsKey(i)) missingOnologies_model_1.add(i);
		}
		
		// get missing ontologies of model 2
		//System.out.println (ontology[0].cntOntology + " " + ontology[1].cntOntology);
		for (int i = 0; i < ontology[1].cntOntology; i++) {
			if (!coveredOntology_model_2.containsKey(i)) missingOnologies_model_2.add(i);
		}
		
		//System.out.println("=====");
		//System.out.println(missingOnologies_model_1);
		
		//System.out.println("=====");
		//System.out.println(missingOnologies_model_2);
		
		return 0;
	}
	
	int getSimilarity () {
		
		float total_weight_model_1 = 0;
		float total_weight_model_2 = 0;
		
		// get parent similarity
		if ( parentRulePath != null ) {
			
		}
		
		// get current similarity
		// get total weight of model 1
		for (int i = 0; i < numModels ; i++) {
			for (int j = 0;  j < ontology[i].cntOntology; j ++) {
				if (i == 0 ) total_weight_model_1 += ontology[i].weights.get(j);
				else total_weight_model_2 += ontology[i].weights.get(j);
			} 
		}
		
		float w_n = 0, Wn = 0, w_r = 0, Wr = 0, f_n;
		for (int i = 0; i < cntRules; i++) {
			ArrayList<Integer> tempOnto1 = onto_in_model_1.get(i);
			ArrayList<Float> tempSatisfice = satisfice.get(i);
			
			//System.out.println("tempSatisfice: " + tempSatisfice + " " +tempSatisfice.size());
			// model 1 has 1 element
				// 1:1 model 2 has 1 element
				// 1:n model 2 has 2+ element // 1:1 convert
			
			// model 1 has 2+ element
				// n:1 model 2 has 1 element  
				// n:m model 2 has 2+ element. // Not support
		
			// (w_n / (Wn*f_n) ) * (w_r / Wr)
			
			for (int j = 0; j < tempOnto1.size(); j++) {
				//System.out.println("tempOnto1.size: " + tempOnto1.size());
				//w_n = ontology[i].weights.get( (int)tempOnto1.get(j) );

				int tempIdx = tempOnto1.get(j);
				w_n = ontology[0].weights.get(tempIdx);
				Wn = total_weight_model_1;
				w_r = tempSatisfice.get(j);
				Wr = maxWeight_relation;
				f_n = coveredOntology_model_1.get(tempOnto1.get(j));
				
				System.out.println (tempIdx+ " " + w_n + " " + Wn + " " + w_r + " " + Wr + " ");
				similarity_model_1 += (w_n / (Wn*f_n) ) * (w_r / Wr);
			}
		}
		
		System.out.println("Similarity : " + similarity_model_1);
		// calculate the covered ontologies
		
		return 0;
	}

}
