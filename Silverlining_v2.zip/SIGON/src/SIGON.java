import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;

import java.awt.BorderLayout;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextPane;
import java.awt.Label;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.FileWriter;
import java.io.IOException;

public class SIGON {

	private static final int TABLE_LEFT = 0;
	private static final int TABLE_RIGHT = 1;
	private static final int TABLE_MIDDLE = 2;
	
	private JFrame frame;
	private JTabbedPane tabbedPane = null;
	private int cntSIG;
	private int cntOntology;
	private int cntCompare;
	private int currentTab;
	
	private ArrayList<Object> tabPanels = null;
	private JTable table;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SIGON window = new SIGON();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SIGON() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		cntSIG = 1;
		cntOntology = 1;
		cntCompare = 1;
		currentTab = -1;
		
		tabPanels = new ArrayList<Object>();
		
		frame = new JFrame();
		frame.setBounds(100, 100, 862, 736);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenu mnTab = new JMenu("Tab");
		menuBar.add(mnTab);
		
		JMenuItem mntmSig = new JMenuItem("SIG");
		mntmSig.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanel("SIG", cntSIG++);
			}
		});
		mnTab.add(mntmSig);
		
		JMenuItem mntmOntology = new JMenuItem("Ontology");
		mntmOntology.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanel("Ontology", cntOntology++);
			}
		});
		mnTab.add(mntmOntology);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(JFrame.EXIT_ON_CLOSE);
			}
		});
		
		JMenuItem mntmCompare = new JMenuItem("Compare");
		mntmCompare.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanel("Compare", cntCompare++);
			}
		});
		mnTab.add(mntmCompare);
		mnTab.add(mntmExit);
		
		/*
		JMenuItem mntmLoad = new JMenuItem("Load");
		mntmLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if ( currentTab == -1 ) return;
				
				if ( tabPanels.get(currentTab).getClass() == PanelDiagram.class) {
					PanelDiagram tabTemp = (PanelDiagram) tabPanels.get(currentTab);
					
					if ( tabTemp.isImageLoaded() == false) {
						tabTemp.loadImage("Image/sig.png");
					}
				}
				
				
			}
		});
		menuBar.add(mntmLoad);
		*/
		
		JMenu mnNewMenu = new JMenu("Model 1");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Load");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadModel(TABLE_LEFT);
			}
		});
		mnNewMenu.add(mntmNewMenuItem_2);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("Save");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveModel(TABLE_LEFT);
			}
		});
		mnNewMenu.add(mntmNewMenuItem_3);
		
		JMenuItem mntmAdd = new JMenuItem("Add");
		mntmAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addRow(TABLE_LEFT);
			}
		});
		mnNewMenu.add(mntmAdd);
		
		JMenuItem mntmDelete = new JMenuItem("Delete");
		mnNewMenu.add(mntmDelete);
		
		JMenu mnNewMenu_1 = new JMenu("Model 2");
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Load");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//load ontologies 
				loadModel(TABLE_RIGHT);
				
				//update the ontologies on the table
				
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Save");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_1);
		
		JMenuItem mntmAdd_1 = new JMenuItem("Add");
		mntmAdd_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addRow(TABLE_RIGHT);
			}
		});
		mnNewMenu_1.add(mntmAdd_1);
		
		JMenuItem mntmDelete_1 = new JMenuItem("Delete");
		mnNewMenu_1.add(mntmDelete_1);
		
		JMenu mnNewMenu_2 = new JMenu("Mapping Rule");
		menuBar.add(mnNewMenu_2);
		
		JMenuItem mntmNewMenuItem_4 = new JMenuItem("Load");
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadModel(TABLE_MIDDLE);
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_4);
		
		JMenuItem mntmNewMenuItem_5 = new JMenuItem("Save");
		mnNewMenu_2.add(mntmNewMenuItem_5);
		
		JMenuItem mntmAdd_2 = new JMenuItem("Add");
		mntmAdd_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addRow(TABLE_MIDDLE);
			}
		});
		mnNewMenu_2.add(mntmAdd_2);
		
		JMenuItem mntmDelete_2 = new JMenuItem("Delete");
		mnNewMenu_2.add(mntmDelete_2);
		
		
		JMenuItem menuItem = new JMenuItem("");
		menuBar.add(menuItem);
		
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if (e.getSource() instanceof JTabbedPane) {
                    JTabbedPane pane = (JTabbedPane) e.getSource();
                    currentTab = pane.getSelectedIndex();
                    //System.out.println("Selected paneNo : " + pane.getSelectedIndex());
                }
			}
		});
		frame.getContentPane().add(tabbedPane, BorderLayout.CENTER);
		

	}
	
	private int loadModel(int tableNumber) {
		if ( currentTab == -1 ) {
			System.out.println("Compare tab is not selected");
			return -1;
		}
		
		if ( tabPanels.get(currentTab).getClass() == PanelCompare.class) {
			PanelCompare tabTemp = (PanelCompare) tabPanels.get(currentTab);
			tabTemp.loadOntology(tableNumber);
			//tabTemp.updateTable(model);
		}
		
		return 0;
	}
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	
	private int saveModel (int model) {
		if ( tabPanels.get(currentTab).getClass() == PanelCompare.class) {
			PanelCompare tabTemp = (PanelCompare) tabPanels.get(currentTab);
			tabTemp.saveModel(model);
		}
		return 0;
	}
	
	private int addRow(int table) {
		if ( tabPanels.get(currentTab).getClass() == PanelCompare.class) {
			PanelCompare tabTemp = (PanelCompare) tabPanels.get(currentTab);
			tabTemp.addRow(table);
		}
		return 0;
	}
	
	private void setPanel(String type, int cnt) {
		
		if ( type.equals("SIG") || type.equals("Ontology") ) {
			PanelDiagram panelTemp = new PanelDiagram(type, cnt);
			tabPanels.add(panelTemp);
			tabbedPane.addTab(type + " " + cnt, panelTemp.getInstancePanel());
		}
		
		if ( type.compareTo("Compare") == 0 ) {
			PanelCompare panelTemp = new PanelCompare(type, cnt);
			tabPanels.add(panelTemp);
			tabbedPane.addTab(type + " " + cnt, panelTemp.getInstancePanel());
		}
		
		
		/*
		for(int i=0; i<tabPanels.size(); i++) {
			JOptionPane.showMessageDialog(frame,i + " " + tabPanels.get(i).instancePanel.isVisible());
		}
		*/
		
		
	}
}
